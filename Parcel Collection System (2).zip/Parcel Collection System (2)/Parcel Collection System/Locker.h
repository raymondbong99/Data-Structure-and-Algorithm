#include <iostream>
using namespace std;

class locker
{
private:
    //Define a node, few pointers and variables name.
    struct node
    {
        string username;
        int user_id;
        string contact;
        string email;
        string item_name;
        double item_mass, total;
        int duration;
        int lock_num, reserved_num;
        string d_dtime, c_dtime;

        node *next;
    };
    node *head;
    node *temp, *temp2;

public:
    //functions used
    locker();
    void lockSpace(int x);
    void addLock();
    void editLock();
    void displayLock();
    void searchLock();
    void removeLock();
    void printLock();
    void bubbleSorting();
};
