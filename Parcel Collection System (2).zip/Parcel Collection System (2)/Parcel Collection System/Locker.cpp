#include <iostream>
#include <fstream>
#include <istream>
#include <iomanip>
#include <stdlib.h>
#include <unistd.h>
#include <windows.h>
#include <time.h>
#include "Locker.h"
#define size 100
using namespace std;


int space[size]; //Locker spaces
int reserved_no= 99; //Reservation number
int cancel = 0; //Cancellation number
char ans;


locker::locker() //Constructor sets the pointer to null.
{
    head = NULL;
}

bool taken = false;//To determine whether the locker number is available or not.


void locker::lockSpace(int x)
{

    if( space[0] == -1 ) //(-1) makes it as taken value.
    {
        taken=true;
        cout<<endl;
        cout<<"The locker space is occupied. \n";
        cout<<"Please choose another locker number from below."<<endl;

        //display array matrix
        int j = 1; //starting value
        while(j < size+1)
        {
            if(space[j-1] == -1)
            {
                j++;
            }
            else
            {
                cout<<"|"<<j<<"|"; //numbering in the ascending order.
                if( j%10 == 0 )
                {
                    cout<<endl;
                }
                j++;
            }
        }
    }
}


void locker::addLock()
{
    int x;

    system("CLS");
    cout<<"////////////////////////////////////////////////"<<endl;
    cout<<"//  Here is the locker renting procedures:    //"<<endl;
    cout<<"//  [1] Insert the user detail.               //"<<endl;
    cout<<"//  [2] Insert the parcel information.        //"<<endl;
    cout<<"//  [3] Display the receipt.                  //"<<endl;
    cout<<"////////////////////////////////////////////////"<<endl<<endl;
    cout<<"Ready to proceed to the steps? [Y/N]: ";
    cin>>ans;
    try//user exception
    {
        if((ans!='y') && (ans!='Y') && (ans!='n') && (ans!='N'))
        {
            throw(ans);
        }
    }
    catch(char a)
    {
        do
        {
            cout<<endl;
            cout<<"Invalid input! Please enter again.";
            cout<<endl;
            cout<<"Please enter only input [Y] or [N]: ";
            cin>>ans;
        } while((ans != 'y') && (ans != 'Y') && (ans !='n') && (ans != 'N'));
    }

    if((ans == 'n')||(ans == 'N'))
    {
        return;
    }
    else
    {
        system("CLS");
        temp = new node;

        cout<<"Please fill in with the correct information: "<<endl<<endl;
        cout<<"==================================================="<<endl;
        cout<<"\tUSER DETAIL REGISTRATION"<<endl;
        cout<<"==================================================="<<endl;
        cout<<"UserID: ";
        cin>>temp->user_id;
        cout<<"Username: ";
        cin>>temp->username;
        cout<<"Contact Number: ";
        cin>>temp->contact;
        cout<<"E-mail: ";
        cin>>temp->email;
        cout<<endl;
        cout<<"==================================================="<<endl;
        cout<<"\tPARCEL INFORMATION REGISTRATION"<<endl;
        cout<<"==================================================="<<endl;
        cout<<"Item Name: ";
        cin>>temp->item_name;
        cout<<"Item Mass(KG): ";
        cin>>temp->item_mass;
        cout<<"Duration(DAY): ";
        cin>>temp->duration;
        cout<<endl;

        do
        {
            cout<<"--------------------------------\n";
            cout<<"Please Enter the Locker Number: ";
            cin>>x;
            while(x>size || x<1)//check for invalid locker number
            {
                cout<<"Invalid. Try again:: ";
                cin >>x;
            }
            if((space[x-1])>-1) //if locker value is more than 0  it's available
            {
                taken = false;
            }
            else
            {
                lockSpace(x);
            }
            space[x-1] = -1; //make current locker space unavailable as -1 value representation
            temp->lock_num = x; //save the value in node(temp)
        } while(taken==true);

        /////////////////////////////////////////////////////////////////////////////////////////////////
        //Rental fee calculation.
        double a = temp->item_mass;
        int b = temp->duration;
        if(a >= 0 || a <= 5)
        {
            temp->total = (a*2.00) + (b*3.00);
        }
        else
        {
            temp->total = (a*3.00) + (b*4.00);
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////

        cout<<endl;
        system("PAUSE");
        system("CLS");

        ////////////////////////////////////////////////////////////////////////////////////////////////////
        cout<<"RENTAL INFORMATION TABLE AS BELOW:"<<endl<<endl;
        cout<<"Mass(KG)"<<setw(30)<<"Charge Per Mass(KG)"<<setw(30)<<"Charge Per Day(RM)"<<endl;
        cout<<"--------------------------------------------------------------------------"<<endl;
        cout<<"0 to 5"<<setw(32)<<"2.00"<<setw(30)<<"3.00"<<"\n";
        cout<<"6 and above"<<setw(27)<<"3.00"<<setw(30)<<"4.00";
        cout<<endl<<endl;
        cout<<"Please kindly wait as the fee is being calculated......"<<endl<<endl<<endl;

        Sleep(2000); //delay 2000 milliseconds = 2 secs

        //Show date and time
        struct tm when;
        time_t now, last;
        time(&now);
        when = *localtime(&now);
        temp->d_dtime = asctime(&when);
        when.tm_mday = when.tm_mday + (temp->duration);
        if((last = mktime(&when)) != (time_t)-1 )
        {
            temp->c_dtime = (temp->duration,asctime(&when));
        }
        else
        {
            cout<<"mktime failed";
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////////////////////////////////////////////////
        cout<<"Your receipt is ready:";
        cout<<endl<<endl;
        cout<<"____________________RECEIPT______________________"<<endl;
        cout<<"|UserID        | "<<setw(2)<<temp->user_id<<endl;
        cout<<"|Username      | "<<setw(2)<<temp->username<<endl;
        cout<<"|Contact       | "<<setw(2)<<temp->contact<<endl;
        cout<<"|E-mail        | "<<setw(2)<<temp->email<<endl;
        cout<<"|Item Name     | "<<setw(2)<<temp->item_name<<endl;
        cout<<"|Item Mass(KG) | "<<setw(2)<<temp->item_mass<<endl;
        cout<<"|Duration(DAY) | "<<setw(2)<<temp->duration<<endl;
        cout<<"|Rental Fee(RM)| "<<setw(2)<<temp->total<<endl;
        cout<<"|Reserved D&T  | "<<setw(2)<<temp->d_dtime;
        cout<<"|Collect D&T   | "<<setw(2)<<temp->c_dtime<<endl;

        reserved_no++;   //increments the reservation numbers
        temp->reserved_num = reserved_no;
        cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::\n";
        cout<< "\tYOUR RESERVATION NUMBER IS :: " << reserved_no<< "\n";
        cout<<"::::::::::::::::::::::::::::::::::::::::::::::::::\n";
        cout<<endl;
        //////////////////////////////////////////////////////////////////////////////////////////////

        //saving process of linked-list
        temp->next = NULL;
        if(head == NULL)
        {
            head = temp;//first data
        }
        else
        {//data afterwards
            temp2 = head;
            while (temp2->next != NULL)
            {
                temp2 = temp2->next;//keep adding until the end of node
            }
            temp2->next = temp;
        }
        system("PAUSE");
        system("CLS");
    }
}


void locker::displayLock()
{
    system("CLS");
    temp=head;
    if(temp == NULL)
    {
        cout<<" [ End of Parcel Collection Lists ]"<<endl;
    }
    else
    {
        int cnt = 1;
        cout << "*****************************************************************************************************************************************"<< endl;
        cout << "\t[ Check Lists ]";
        cout << "\n\n";
        cout << "\t|NO.|\tUser_ID|\t Username|\tContact_No|\t\tEmail|\t\tItem_Name| Locker_No| Reservation_No|\n";

        while(temp != NULL)	// Display details for what temp points to
        {
            cout << "\t  " << cnt <<setw(12);
            cout << temp->user_id <<setw(18);
            cout << temp->username <<setw(17);
            cout << temp->contact <<setw(19);
            cout << temp->email <<setw(20);
            cout << temp->item_name <<setw(11);
            cout << temp->lock_num <<setw(16);
            cout << temp->reserved_num <<"\n";
            // Move to next node
            // Loop until pointer points to null.
            temp=temp->next;
            cnt++;
        }
        cout << "\n\n";
        cout << "Would you like to perform sorting? [Y/N]: ";
        cin >> ans;
        try//user exception
        {
            if((ans!='y') && (ans!='Y') && (ans!='n') && (ans!='N'))
            {
                throw(ans);
            }
        }
        catch(char a)
        {
            do
            {
                cout<<endl;
                cout<<"Invalid input! Please enter again.";
                cout<<endl;
                cout<<"Please enter only input [Y] or [N]: ";
                cin>>ans;
            } while((ans != 'y') && (ans != 'Y') && (ans !='n') && (ans != 'N'));
        }
        if((ans == 'n')||(ans == 'N'))
        {
            return;
        }
        else
        {
            bubbleSorting();
        }
    }
    system("PAUSE");
}


void locker::editLock()
{
    int option , next_lock;
    system("CLS");
    cout << endl;
    cout << "***************************************************"<<endl;
    cout << "Please enter your locker number: ";//choose other locker.
    cin >> option;
    node *current;
    current= head;

    while(current != NULL)
    {
        if ( current->lock_num == option )
        {
            break;
            current = current->next;// check whether the locker number can be found in the nodes.
        }
        else
        {
            cout << endl;
            cout << "Please rent a locker for your parcel.\n";
            system("PAUSE");
            return;
        }
    }
    cout << endl;
    cout << "Please choose another locker number from below:";
    cout << "\n";
    int j = 1;
    while (j < size+1)//display array matrix and retrieve back deleted locker number
    {
        if ( space[j-1] == -1)
        {
            j++;
        }
        else
        {
            cout <<"| " << j << "|";
            if ( j%10 == 0 )
            {
                cout << endl;
            }
            j++;
        }
    }
    cout << "\nInsert: ";
    cin >> next_lock;
    space[current->lock_num-1]=0;//insert back the current locker number
    current->lock_num = next_lock;// pick the new locker number
    space[next_lock-1] = -1;// set the new locker number as occupied.
}


void locker::searchLock()
{
    int id;
    system("CLS");
    cout << endl;
    cout << "**************************************************"<<endl;
    cout << "Please enter your user ID here: ";//Users'ID for security purpose
    cin >> id;

    node *current = head;
    while (current != NULL)
    {
        if (current->user_id == id) //found
        {
            cout << endl;
            cout << "**************************************************\n";
            cout << "UserID : " << current->user_id << endl;
            cout << "Username : " << current->username << endl;
            cout << "Contact Number : " << current->contact << endl;
            cout << "Email : " << current->email << endl;
            cout << "Reserved D&T : "<< current->d_dtime;
            cout << "Collect D&T : "<< current->c_dtime;
            cout << "Locker Number: " << current->lock_num << endl;
            cout << "Reservation No. " << current->reserved_num<< endl;
            cout << "**************************************************\n";
            cout << endl;
            cout << "Would you like get a notification? [Y/N]: ";
            cin >> ans;
            try//user exception
            {
                if((ans!='y') && (ans!='Y') && (ans!='n') && (ans!='N'))
                {
                    throw(ans);
                }
                }
            catch(char a)
            {
                do
                {
                    cout<<endl;
                    cout<<"Invalid input! Please enter again.";
                    cout<<endl;
                    cout<<"Please enter only input [Y] or [N]: ";
                    cin>>ans;
                } while((ans != 'y') && (ans != 'Y') && (ans !='n') && (ans != 'N'));
            }
            if((ans == 'n')||(ans == 'N'))
            {
                return;
            }
            else
            {
                fstream file;
                file.open("notification.txt", ios::out | ios::app | ios::binary);
                if(!file)
                {
                    cout << "Error in opening the file!!.";
                    return;
                }
                else
                {
                    file << "ID: " << current->user_id <<endl;
                    file << "Username: " << current->username <<endl;
                    file << "Phone: " << current->contact <<endl;
                    file << "E-mail: " << current->email <<endl;
                    file << "I_name: " << current->item_name <<endl;
                    file << "I_mass: " << current->item_mass <<endl;
                    file << "Duration: " << current->duration <<endl;
                    file << "Total: " << current->total << endl;
                    file << "Reserved: " << current->d_dtime;
                    file << "Collect: " << current->c_dtime;
                    file << "Locker_no: " << current->lock_num << endl;
                    file << "Reserved_no: " << current->reserved_num <<endl;
                    file << endl;
                }
                cout << "Notification sent successfully!" <<endl<<endl;
                file.close();
                system("PAUSE");
                return;
            }
            current = current->next;
        }
    }
    cout << "##  Sorry!!! NOT FOUND  ##\n\n";
    system("PAUSE");
    return;
}


void locker::removeLock()
{
    int rnum;
    system("CLS");
    cout << endl;
    cout << "*****************************************************"<<endl;
    cout << "Please Enter your reservation number here: ";
    cin >> rnum;

    node *current = head;
    if(current!=NULL)
    {   // error checking for empty node deletion which cause segment fault error.
        if(head->reserved_num == rnum )//first node.
        {
            node *del = head;// new pointer point to the location as head pointing to.
            head = head->next;// point to the next node
            delete del;// remove the current node that just left by the head pointer.
            space[0] = 0;//reset the locker number.
            cancel++;
            cout << "Remove successfully!\n";
            cout << endl;
            system("PAUSE");
            return;
        }
        else
        {
            node *pre, *current; //To delete a middle or last node.
            pre = head;//
            current = head->next;
            while(current != NULL)
            {
                if ( current->reserved_num == rnum )//find the particular node.
                {
                    break;
                }
                pre = current;// pre pointer points to the same node as current pointing to.
                current = current->next;// points to the next
            }
            space[current->lock_num-1] = 0;//insert back locker number.
            if (current != NULL )
                pre->next = current->next;//link to others
        }
        cancel++;// count the number cancellation

    }// error checking if statement ends here
    else
    {
        cout<<endl;
        cout<<"****************************"<<endl;
        cout<<"****Invalid ENTRY (null)****"<<endl;
        cout<<"****************************"<<endl;
        system("PAUSE");
    }
}


void locker::printLock()//This function prints the status report of the parcel collection system.
{
    int count = 0;
    for (int i =0; i < size; i++ )
    {
        if (space[i] == -1)
        {
            count++;
        }
    }
    cout<<endl;
    cout<<"[SYSTEM STATUS]"<<endl;
    cout<<"The number of lockers occupied are: " << count <<endl;
    cout<<"The number of cancellations are: " << cancel <<endl;
    system("PAUSE");
}


void locker::bubbleSorting()
{
    int cnt2 = 1;
    cout << "*****************************************************************************************************************************************"<< endl;
    cout << "\t[ Check Lists ]";
    cout << "\n\n";
    cout << "\t|NO.|\tUser_ID|\t Username|\tContact_No|\t\tEmail|\t\tItem_Name| Locker_No| Reservation_No|\n";
    node *end = NULL;
    while(end!= head)
    {
        node *swap1;
        swap1 = head;
        while( swap1->next != end )
        {
            if(swap1->lock_num < swap1->next->lock_num)// sort by locker number.
            {
                node *swap2 = swap1->next;
                swap1->next = swap2->next;
                swap2->next = swap1;
                if(swap1 == head)
                {
                    head = swap2;
                    swap1 = swap2;
                }
                else
                {
                    swap1 = swap2;
                    temp->next = swap2;
                }
            }
            temp = swap1;
            swap1 = swap1->next;
        }
        // update the end to the last sorted element:
        end = swap1;
        cout << "\t  " << cnt2 <<setw(12);
        cout << end->user_id <<setw(18);
        cout << end->username <<setw(17);
        cout << end->contact <<setw(19);
        cout << end->email <<setw(20);
        cout << end->item_name <<setw(11);
        cout << end->lock_num <<setw(16);
        cout << end->reserved_num <<"\n";
        cnt2++;
    }
    cout<<endl;
}

