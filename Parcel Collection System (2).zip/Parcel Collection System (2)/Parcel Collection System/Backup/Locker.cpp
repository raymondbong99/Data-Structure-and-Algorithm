#include <iostream>
#include <fstream>
#include <istream>
#include <iomanip>
#include <stdlib.h>
#include <unistd.h>
#include <windows.h>
#include <time.h>
#include "Locker.h"
#define size 100
using namespace std;


int space[size]; //locker spaces
int reserved_no= 99; //reservation number
int cancel = 0; //Cancellation number
char ans;


locker::locker() //Constructor sets the pointer to null.
{
	head = NULL;
}

bool taken = false;

void locker::lockSpace(int x)
{
        for( int i = 0; i<size; i++)
        {
                if( space[i] == -1 )
                {
                    taken=true;
                    cout<<endl;
                    cout<<"\t\tThe locker space is occupied. \n";
                    cout<<"\t\tPlease choose another locker number from below."<<endl;

                    //display array matrix
                    int j = 1;
                    while(j < size+1)
                    {
                        if(space[j-1] == -1)
                        {
                            j++;
                        }
                        else
                        {
                            cout<<"\t|"<<j<<"|";
                            if( j%10 == 0 )
                            {
                               cout<<endl;
                            }
                            j++;
                        }
                    }
                }
        }
}


void locker::addLock()
{
    int x;

    system("CLS");
    cout<<"\t\t////////////////////////////////////////////////"<<endl;
    cout<<"\t\t//  Here is the locker renting procedures:    //"<<endl;
    cout<<"\t\t//  [1] Insert the user detail.               //"<<endl;
    cout<<"\t\t//  [2] Insert the parcel information.        //"<<endl;
    cout<<"\t\t//  [3] Display the receipt.                  //"<<endl;
    cout<<"\t\t////////////////////////////////////////////////"<<endl<<endl;
    cout<<"\t\tReady to proceed to the steps? [Y/N]: ";
    cin>>ans;
    try
    {
        if((ans!='y') && (ans!='Y') && (ans!='n') && (ans!='N'))
        {
            throw(ans);
        }
    }
    catch(char a)
    {
        do
        {
            cout<<endl;
            cout<<"\t\tInvalid input! Please enter again.";
            cout<<endl;
            cout<<"\t\tPlease enter only input [Y] or [N]: ";
            cin>>ans;
        }while((ans != 'y') && (ans != 'Y') && (ans !='n') && (ans != 'N'));
    }

    if((ans == 'n')||(ans == 'N'))
    {
       return;
    }
    else
    {
                system("CLS");
                temp = new node;
                //node * temp = head; //made copy of head
                ofstream outFile("database.txt");  //created new file
                cout<<"\t\tPlease fill in with the correct information: "<<endl<<endl;
                cout<<"\t\t==================================================="<<endl;
                cout<<"\t\t\tUSER DETAIL REGISTRATION"<<endl;
                cout<<"\t\t==================================================="<<endl;\
                cout<<"\t\tUserID: ";
                cin>>temp->user_id;
                cout<<"\t\tUsername: ";
                cin>>temp->username;
                cout<<"\t\tContact Number: ";
                cin>>temp->contact;
                cout<<"\t\tE-mail: ";
                cin>>temp->email;
                cout<<endl;
                cout<<"\t\t==================================================="<<endl;
                cout<<"\t\t\tPARCEL INFORMATION REGISTRATION"<<endl;
                cout<<"\t\t==================================================="<<endl;
                cout<<"\t\tItem Name: ";
                cin>>temp->item_name;
                cout<<"\t\tItem Mass(KG): ";
                cin>>temp->item_mass;
                cout<<"\t\tDuration(DAY): ";
                cin>>temp->duration;
                cout<<endl;

                do
                {
                    cout<<"\t\t--------------------------------\n";
                    cout<<"\t\tPlease Enter the Locker Number: ";
                    cin>>x;
                    while(x>size)//check for invalid locker number
                    {
                        cout<<"\t\tInvalid. Try again:: ";
                        cin >>x;
                    }
                    if((space[x-1])>-1) //if locker value is 0 or more than it's available
                    {
                        taken = false;
                    }
                    else
                    {
                        lockSpace(x);
                    }
                    space[x-1] = -1; //make current locker space unavailable as -1 value representation
                    temp->lock_num = x;
                }while(taken==true);

                //Rental fee calculation.
                double a = temp->item_mass;
                int b = temp->duration;
                if(a >= 0 || a <= 5)
                {
                    temp->total = (a*2.00) + (b*3.00);
                }
                else
                {
                    temp->total = (a*3.00) + (b*4.00);
                }


                cout<<endl;
                system("PAUSE");
                system("CLS");


                cout<<"\t\tRENTAL INFORMATION TABLE AS BELOW:"<<endl<<endl;
                cout<<"\t\tMass(KG)"<<setw(30)<<"Charge Per Mass(KG)"<<setw(30)<<"Charge Per Day(RM)"<<endl;
                cout<<"\t\t--------------------------------------------------------------------------"<<endl;
                cout<<"\t\t0 to 5"<<setw(32)<<"2.00"<<setw(30)<<"3.00"<<"\n";
                cout<<"\t\t6 and above"<<setw(27)<<"3.00"<<setw(30)<<"4.00";
                cout<<endl<<endl;
                cout<<"\t\tPlease kindly wait as the fee is being calculated......"<<endl<<endl<<endl;

                Sleep(2000); //delay 2000 milliseconds = 2 secs

                //Show date and time
                struct tm when;
                time_t now, last;
                time(&now);
                when = *localtime(&now);
                temp->d_dtime = asctime(&when);
                when.tm_mday = when.tm_mday + (temp->duration);
                if((last = mktime(&when)) != (time_t)-1 )
                {
                    temp->c_dtime = (temp->duration,asctime(&when));
                }
                else
                {
                    cout<<"mktime failed";
                }
                //###################################################################################
                cout<<"\t\tYour receipt is ready:";
                cout<<endl<<endl;
                cout<<"\t\t____________________RECEIPT______________________"<<endl;
                cout<<"\t\t|UserID        | "<<setw(2)<<temp->user_id<<endl;
                cout<<"\t\t|Username      | "<<setw(2)<<temp->username<<endl;
                cout<<"\t\t|Contact       | "<<setw(2)<<temp->contact<<endl;
                cout<<"\t\t|E-mail        | "<<setw(2)<<temp->email<<endl;
                cout<<"\t\t|Item Name     | "<<setw(2)<<temp->item_name<<endl;
                cout<<"\t\t|Item Mass(KG) | "<<setw(2)<<temp->item_mass<<endl;
                cout<<"\t\t|Duration(DAY) | "<<setw(2)<<temp->duration<<endl;
                cout<<"\t\t|Rental Fee(RM)| "<<setw(2)<<temp->total<<endl;
                cout<<"\t\t|Reserved D&T  | "<<setw(2)<<temp->d_dtime;
                cout<<"\t\t|Collect D&T   | "<<setw(2)<<temp->c_dtime<<endl;

                reserved_no++;   //increments the reservation numbers
                temp->reserved_num = reserved_no;
                cout<<"\t\t::::::::::::::::::::::::::::::::::::::::::::::::::\n";
                cout<< "\t\t\tYOUR RESERVATION NUMBER IS :: " << reserved_no<< "\n";
                cout<<"\t\t::::::::::::::::::::::::::::::::::::::::::::::::::\n";
                cout<<endl;

                //saving process of linked-list

                //outFile.write(reinterpret_cast<char*>(&temp), sizeof(temp));

                for(int x=1; x<=size; x++) //Until link list end
                {
                    outFile << temp->username <<endl;
                    outFile << temp->user_id <<endl;
                    outFile << temp->contact <<endl;
                    outFile << temp->email <<endl;
                    outFile << temp->item_name <<endl;
                    outFile << temp->item_mass <<endl;
                    outFile << temp->duration <<endl;
                    outFile << temp->total << endl;
                    outFile << temp->d_dtime << endl;
                    outFile << temp->c_dtime <<endl;
                    outFile << temp->lock_num << endl;
                    outFile << temp->reserved_num;
                    outFile << endl;
                    temp = temp->next; //move temp to next node
                }
                outFile.close();
                //temp->next = NULL;
                if(head == NULL)
                {
                    head = temp;
                }
                else
                {
                    temp2 = head;
                    while (temp2->next != NULL)
                    {
                        temp2 = temp2->next;
                    }
                    temp2->next = temp;
                }
                system("PAUSE");
                system("CLS");
    }
}


void locker::displayLock()
{
    system("CLS");
    temp=head;
	if(temp == NULL)
	cout<<" [ End of Parcel Collection Lists ]"<<endl;
	else
	{	int cnt = 1;
        cout << endl;
        cout << "\t[ Check Lists ]";
        cout << "\n\n";
		cout << "\t|NO.|\tUser_ID|\t Username|\tContact_No|\t\tEmail|\t\tItem_Name| Locker_No| Reservation_No|\n";

		while(temp != NULL)	// Display details for what temp points to
		{
			cout << "\t  " << cnt <<setw(12);
			cout << temp->user_id <<setw(18);
			cout << temp->username << setw(17);
			cout << temp->contact << setw(19);
			cout << temp->email <<setw(20);
			cout << temp->item_name <<setw(11);
			cout << temp->lock_num <<setw(16);
			cout << temp->reserved_num <<"\n";
			// Move to next node
			temp=temp->next;
			cnt++;
		}
		cout << "\n\n";
		system("PAUSE");
	}
}


void locker::editLock()
{
    int option , next_lock;
    system("CLS");
    cout << endl;
    cout << "\t\t***************************************************"<<endl;
	cout << "\t\tPlease enter your locker number: ";
	cin >> option;
	node *current;
	current= head;

	while(current != NULL)
	{
		if ( current->lock_num == option )
        {
            break;
            current = current->next;
        }
		else
        {
            cout << endl;
            cout << "\t\tPlease rent a locker for your parcel.";
            system("PAUSE");
            return;
        }
	}
        cout << endl;
        cout << "\t\tPlease choose another locker number from below:";
        cout << "\n";
		int j = 1;
		while (j < size+1)
		{
			if ( space[j-1] == -1)
            {
                j++;
            }
			else
			{
                cout <<"| " << j << "|";
                if ( j%10 == 0 )
                {
                  cout << endl;
                }
                j++;
			}
		}
	cin >> next_lock;
    space[current->lock_num-1]=0;
	current->lock_num = next_lock;
	space[next_lock-1] = -1;
}


void locker::searchLock()
{
    int id;
    system("CLS");
    cout << endl;
    cout << "\t\t**************************************************"<<endl;
    cout << "\t\tPlease enter your user ID here: ";
    cin >> id;

    node *current = head;
    while (current != NULL)
    {
        if (current->user_id == id) //found
        {
            cout << endl;
            cout << "\t\t**************************************************\n";
            cout << "\t\tUserID : " << current->user_id << endl;
            cout << "\t\tUsername : " << current->username << endl;
            cout << "\t\tContact Number : " << current->contact << endl;
            cout << "\t\tEmail : " << current->email << endl;
            cout << "\t\tCollect D&T : "<< current->c_dtime << endl;
            cout << "\t\tLocker Number: " << current->lock_num << endl;
            cout << "\t\tReservation No. " << current->reserved_num<< endl;
            cout << "\t\t**************************************************\n";
            system("PAUSE");
            return;
        }
        current = current->next;
    }
    cout << "\t\t##  Sorry!!! NOT FOUND ##\n\n";
    system("PAUSE");
}


void locker::removeLock()
{
    int rnum;
    system("CLS");
    cout << endl;
    cout << "\t\t*****************************************************"<<endl;
	cout << "\t\tPlease Enter your reservation number here: ";
	cin >> rnum;

    node *current = head;
    if(current!=NULL)
    { // error checking for empty node deletion which cause segment fault error.
        if(head->reserved_num == rnum )//first node.
		{
			node *del = head;
			head = head->next;
			delete del;
			space[0] = 0;
			cancel++;
			cout << "\t\tRemove successfully!";
			system("PAUSE");
			return;
		}
		else
		{
			node *pre, *current; //To delete a middle or last node.
			pre = head;
			current = head->next;
			while(current != NULL)
			{
				if ( current->reserved_num == rnum )
                {
                    break;
                }
				pre = current;
				current = current->next;
			}
			space[current->lock_num-1] = 0;
			if (current != NULL )
			pre->next = current->next;
		}
        cancel++;
        //reserve--;
        //temp->reserve_num=reserve;
    }// error checking if statement ends here
    else
    {
        cout<<"****************************"<<endl;
		cout<<"****Invalid ENTRY (null)****"<<endl;
		cout<<"****************************"<<endl;
		system("PAUSE");
    }
}


void locker::printLock()//This function prints the status report of the parcel collection system.
{
    int count = 0;
	for (int i =0; i < size; i++ )
	{
		if (space[i] == -1)
			count++;
	}
	cout<<endl;
	cout<<"\t\t[SYSTEM STATUS]"<<endl;
	cout<<"\t\tThe number of lockers occupied are: " << count <<endl;
	cout<<"\t\tThe number of cancellations are: " << cancel <<endl;
	system("PAUSE");
}






