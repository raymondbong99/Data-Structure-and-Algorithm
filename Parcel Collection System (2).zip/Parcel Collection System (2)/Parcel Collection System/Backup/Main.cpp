#include <iostream>
#include <fstream>
#include <iomanip>
#include <stdlib.h>
#include <unistd.h>
#include "Locker.h"
using namespace std;

int main()
{
    locker l;
    char exitChoice;
    char option;

    do
    {
        system("CLS");
        cout<<"\t\t############################################################"<<endl;
        cout<<"\t\t##                       Welcome to                       ##"<<endl;
        cout<<"\t\t##                PARCEL COLLECTION SYSTEM                ##"<<endl;
        cout<<"\t\t############################################################"<<endl<<endl;
        cout<<"\t\t____________________WHAT CAN WE HELP YOU?___________________"<<endl<<endl;
        cout<<"\t\t[1] [ADD] Rent a new locker."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[2] [EDIT] Modify an existing locker."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[3] [SEARCH] Look for a your parcel."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[4] [DISPLAY] Show all rented locker history."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[5] [DELETE] Cancel a parcel placement."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[6] [PRINT] Print current system status."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n";
        cout<<"\t\t[7] [EXIT] Close the program."<<endl;
        cout<<"\t\t ----------------------------------------------------------- \n\n";
        cout<<"\t\tInsert your selection: ";
        cin>>option;

        switch(option)
        {
            case '1':
                l.addLock();
                break;

            case '2':
                l.editLock();
                break;

            case '3':
                l.searchLock();
                break;

            case '4':
                l.displayLock();
                break;

            case '5':
                l.removeLock();
                break;

            case '6':
                l.printLock();
                break;

            case '7':
                ExitProgram:
                cout<<endl;
                cout<<"\t\tProgram terminating. Are you sure? [Y/N]: ";
                cin>> exitChoice;
                if (exitChoice == 'y' || exitChoice == 'Y')
                {
                    cout<<endl;
                    cout<<"\t\tGood bye ~ See you again!"<<endl;
                    return 0;
                }
                else if (exitChoice == 'n' || exitChoice == 'N')
                {
                    system("cls");
                    main();
                }
                else
                {
                    cout<<"\t\tNext time choose after read the corresponding line."<<endl;
                    goto ExitProgram;
                }
                break;

            default:
                cout<<endl<<endl;
                cout<<"\t\tInvalid input! Please try again."<<endl;
                system("cls");
                break;
        }
    }while(option != 5);

}





